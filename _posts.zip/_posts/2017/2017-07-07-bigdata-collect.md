---
layout: post
title: 大数据学习资料汇总
category: bigdata
tags: [bigdata]
no-post-nav: true
---


收集大数据相关的学习资料


## 博客

- [纯洁的微笑](http://www.ityouknow.com)

- [粉丝日志](http://blog.fens.me/series-hadoop-family/)


## 网站

http://bigdata.evget.com/


## 开源项目