---
layout: post
title: git 使用总结
category: other
tags: [other]
---

git 使用总结


## git 常常用命令

1、查看文件状态
> git status 

2、查看历史提交记录
> git log

退出输入q





thymeleaf







## 问题处理

